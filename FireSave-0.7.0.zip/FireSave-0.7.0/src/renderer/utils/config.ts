// eslint-disable-next-line
export const SENTRY_DSN =
  "https://3005bff882b441eda4689afb29ab3cae@o240795.ingest.sentry.io/5595121";

export const TOASTER_DEFAULT_AUTO_CLOSE = 5000;
